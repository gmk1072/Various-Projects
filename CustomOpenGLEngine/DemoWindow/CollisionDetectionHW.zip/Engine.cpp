#include "Engine.h"
Engine::Engine()
{
}
Engine::~Engine()
{
	for (int i = 0; i < objectAmount; i++)
	{
		glDeleteTextures(2, &objects[i].texid);
	}
}
bool Engine::init()
{
	if (glfwInit() == GL_FALSE)
	{
		return false;
	}
	GLFWwindowPtr = glfwCreateWindow(800, 600, " Gavin DSA1 Engine", NULL, NULL);
	if (GLFWwindowPtr != nullptr)
	{
		glfwMakeContextCurrent(GLFWwindowPtr);
	}
	else {
		glfwTerminate();
		return false;
	}
	if (glewInit() != GLEW_OK)
	{
		glfwTerminate();
		return false;
	}
	InputManager::init(GLFWwindowPtr);
	objectAmount = 8;
	for (int i = 0; i < objectAmount; i++)
	{
		objects.push_back(Object());
		objects[i].filename = "textures/texture2.png";//rock
		objects[i].transform.loc = glm::vec3(0, 0, 0);
		objects[i].transform.rot = glm::vec3(0, 0, 0);
		objects[i].transform.size = glm::vec3(1, 1, 1);
		objects[i].rigidBody.velocity = glm::vec3(0, 0, 0);
		objects[i].rigidBody.force = glm::vec3(0, 0, 0);
		objects[i].rigidBody.mass = 1;
		objects[i].collisionType = COLLIDERLESS;
	}
	//object 0
	//default
	//object 1
	objects[1].filename = "textures/texture1.png";//brick
	objects[1].transform.loc = glm::vec3(0, 0, 0);
	objects[1].transform.size = glm::vec3(1, .4, 1);
	//object 2
	objects[2].filename = "textures/texture4.png";//spike
	objects[2].transform.loc = glm::vec3(-.1, -.32, 0);
	objects[2].transform.size = glm::vec3(.08, .08, .08);
	objects[2].collisionType = AABB;
	//object 3
	objects[3].filename = "textures/texture4.png";//spike
	objects[3].transform.loc = glm::vec3(0, -.32, 0);
	objects[3].transform.size = glm::vec3(.08, .08, .08);
	objects[4].collisionType = AABB;
	//object 4
	objects[4].filename = "textures/texture4.png";//spike
	objects[4].transform.loc = glm::vec3(.1, -.32, 0);
	objects[4].transform.size = glm::vec3(.08, .08, .08);
	objects[4].collisionType = AABB;
	//object 5
	objects[5].filename = "textures/texture5.png";//cream cheese
	objects[5].transform.loc = glm::vec3(.6, -.35, 0);
	objects[5].transform.size = glm::vec3(.05, .05, .03);
	objects[5].collisionType = AABB;
	//object 6
	objects[6].filename = "textures/texture6.png";//bagel
	objects[6].transform.loc = glm::vec3(-.5, -.35, 0);
	objects[6].transform.size = glm::vec3(.05, .05, .05);
	objects[6].collisionType = SPHERE;
	//object 7
	objects[7].filename = "textures/texture3.png";//bullet white
	objects[7].transform.loc = glm::vec3(1.3, -.2, 0);
	objects[7].transform.size = glm::vec3(.025, .005, .1);
	objects[7].collisionType = AABB;
	return true;
}
bool Engine::bufferModel()
{
	std::vector<glm::vec3> locs ={{ 1, 1, 0 },{ -1, 1, 0 },{ -1, -1, 0 },{ 1, -1, 0 }};
	std::vector<unsigned int> locInds = { 0,1,2,0,2,3};
	vertCount = locInds.size();
	std::vector<glm::vec3> vertBufData(vertCount);
	for (unsigned int i = 0; i < vertCount; i++)
	{
		vertBufData[i] = locs[locInds[i]];
	}
	glGenVertexArrays(1, &vertArr);
	glGenBuffers(1, &vertBuf);
	glBindVertexArray(vertArr);
	glBindBuffer(GL_ARRAY_BUFFER, vertBuf);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vertCount, &vertBufData[0], GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(glm::vec3), 0);
	glClearColor(0.392f, 0.584f, 0.929f, 1.0f);
	return true;
}
bool Engine::useTextures(Object& o)
{
	std::vector<Vertex> uvCoord
	{
		Vertex{glm::vec3(1, 1, 0),glm::vec2(1, 1)},
		Vertex{glm::vec3(-1, 1, 0),glm::vec2(0, 1)},
		Vertex{glm::vec3(-1, -1, 0),glm::vec2(0, 0)},
		Vertex{glm::vec3(1, -1, 0),	glm::vec2(1, 0)}
	};
	vector<unsigned int> locInds = { 0,1,2,0,2,3 };
	uvVertCount = locInds.size();
	vector<unsigned int> uvInds = { 0,1,2,0,2,3 };
	vector<Vertex> vertBufData(uvVertCount);
	for (unsigned int i = 0; i < uvVertCount; i++)
	{
		vertBufData[i] = uvCoord[uvInds[i]];
	}
	glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex) * uvVertCount, &vertBufData[0], GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)sizeof(glm::vec3));
	//texture loading
	FIBITMAP* texture1;
	texture1 = FreeImage_Load(FIF_PNG, o.filename);
	FIBITMAP* image32Bit1 = FreeImage_ConvertTo32Bits(texture1);
	FreeImage_Unload(texture1);
	glActiveTexture(GL_TEXTURE0);
	glGenTextures(1, &o.texid);
	glBindTexture(GL_TEXTURE_2D, o.texid);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_SRGB_ALPHA, FreeImage_GetWidth(image32Bit1), FreeImage_GetHeight(image32Bit1),
		0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(image32Bit1));
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	FreeImage_Unload(image32Bit1);
	return true;
}

bool Engine::collides(const Object &o1, const Object &o2)
{
	if (o1.collisionType == COLLIDERLESS || o2.collisionType == COLLIDERLESS)
	{
		return false;
	}
	if (o1.collisionType == SPHERE && o2.collisionType == SPHERE)
	{
		if (glm::distance(o1.transform.loc, o2.transform.loc) > (o1.transform.size.x + o2.transform.size.x))
		{
			return false;
		}
	}
	if (o1.collisionType == AABB && o2.collisionType == AABB)
	{
		if (glm::distance(o1.transform.loc.x, o2.transform.loc.x) > (o1.transform.size.x + o2.transform.size.x))
		{
			return false;
		}
		if (glm::distance(o1.transform.loc.y, o2.transform.loc.y) > (o1.transform.size.y + o2.transform.size.y))
		{
			return false;
		}
		if (glm::distance(o1.transform.loc.z, o2.transform.loc.z) > (o1.transform.size.z + o2.transform.size.z))
		{
			return false;
		}
	}
	if (o1.collisionType == SPHERE)
	{
		glm::vec3 sphereLocation = o1.transform.loc - o2.transform.loc;
		glm::vec3 closestPoint;
		// x axis
		if (sphereLocation.x < -o2.transform.size.x / 2.0)
		{
			closestPoint.x = -o2.transform.size.x/ 2.0;
		}
		else if (sphereLocation.x > o2.transform.size.x/ 2.0)
		{
			closestPoint.x = o2.transform.size.x / 2.0;
		}
		else 
		{
			closestPoint.x = sphereLocation.x;
		}
		// y axis
		if (sphereLocation.y < -o2.transform.size.y / 2.0)
		{
			closestPoint.y = -o2.transform.size.y / 2.0;
		}
		else if (sphereLocation.y > o2.transform.size.y / 2.0)
		{
			closestPoint.y = o2.transform.size.y / 2.0;
		}
		else
		{
			closestPoint.y = sphereLocation.y;
		}
		// z axis
		if (sphereLocation.z < -o2.transform.size.z / 2.0)
		{
			closestPoint.z = -o2.transform.size.z / 2.0;
		}
		else if (sphereLocation.x > o2.transform.size.z / 2.0)
		{
			closestPoint.z = o2.transform.size.z / 2.0;
		}
		else
		{
			closestPoint.z = sphereLocation.z;
		}

		glm::vec3 dist = sphereLocation - closestPoint;
		if (dist.x*dist.x + dist.y*dist.y + dist.z*dist.z < o1.transform.size.x*o1.transform.size.x)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	if (o2.collisionType == SPHERE)
	{
		glm::vec3 sphereLocation = o2.transform.loc - o1.transform.loc;
		glm::vec3 closestPoint;
		// x axis
		if (sphereLocation.x < -o1.transform.size.x / 2.0)
		{
			closestPoint.x = -o1.transform.size.x / 2.0;
		}
		else if (sphereLocation.x > o1.transform.size.x / 2.0)
		{
			closestPoint.x = o1.transform.size.x / 2.0;
		}
		else
		{
			closestPoint.x = sphereLocation.x;
		}
		// y axis
		if (sphereLocation.y < -o1.transform.size.y / 2.0)
		{
			closestPoint.y = -o1.transform.size.y / 2.0;
		}
		else if (sphereLocation.y > o1.transform.size.y / 2.0)
		{
			closestPoint.y = o1.transform.size.y / 2.0;
		}
		else
		{
			closestPoint.y = sphereLocation.y;
		}
		// z axis
		if (sphereLocation.z < -o1.transform.size.z / 2.0)
		{
			closestPoint.z = -o1.transform.size.z / 2.0;
		}
		else if (sphereLocation.x > o1.transform.size.z / 2.0)
		{
			closestPoint.z = o1.transform.size.z / 2.0;
		}
		else
		{
			closestPoint.z = sphereLocation.z;
		}

		glm::vec3 dist = sphereLocation - closestPoint;
		if (dist.x*dist.x + dist.y*dist.y + dist.z*dist.z < o2.transform.size.x*o2.transform.size.x)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	return true;
}

bool Engine::gameLoop()
{	
	//index = 0;
	//current time of the program
	t = (float)glfwGetTime();
	//initializes each of the textures for the objects
	for (int i = 0; i < objectAmount; i++)
	{
		useTextures(objects[i]);
	}
	//gets the direction of the 
	int direction = (objects[6].rigidBody.velocity.x < 0 ? -1 : 1);
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	while (!glfwWindowShouldClose(GLFWwindowPtr))
	{
		glfwPollEvents();
		pt = t;
		t = (float)glfwGetTime();
		dt = t - pt;
		glClear(GL_COLOR_BUFFER_BIT);
		glBindVertexArray(vertArr);
		float minHeight = -.35f;
		if (objects[6].rigidBody.velocity == glm::vec3())
		{
			direction = 0;
		}

		for (int i = 0; i < objectAmount; i++)
		{
			objects[i].transform.matrix =glm::translate(objects[i].transform.loc)*glm::yawPitchRoll(objects[i].transform.rot.y,objects[i].transform.rot.x,objects[i].transform.rot.z)*glm::scale(objects[i].transform.size);
			objects[i].rigidBody.force.x = 0;
			glUniformMatrix4fv(2, 1, GL_FALSE, &objects[i].transform.matrix[0][0]);
			glBindTexture(GL_TEXTURE_2D, objects[i].texid);
			glDrawArrays(GL_TRIANGLES, 0, vertCount);
			if (InputManager::getKey(GLFW_KEY_D))
			{
				objects[6].rigidBody.force.x = 50;//20;
			}
			if (InputManager::getKey(GLFW_KEY_A))
			{
				objects[6].rigidBody.force.x = -50;// 20;
			}
			if (InputManager::getKey(GLFW_KEY_SPACE) && objects[6].transform.loc.y == minHeight)//will need to be when colliding
			{
				objects[6].rigidBody.force.y = 120;// 60;
			}
			if (InputManager::getKey(GLFW_MOUSE_BUTTON_1) && (objects[7].transform.loc.x > 1 || objects[7].transform.loc.x < -1))
			{
				objects[7].transform.loc = objects[6].transform.loc;
				direction = (objects[6].rigidBody.velocity.x < 0 ? -1 : 1);
			}
			if(!(objects[7].transform.loc.x  > 2 || objects[7].transform.loc.x <-2))
			{ 
				objects[7].rigidBody.velocity.x = 5 * direction;
			}
			if (i != 6)
			{
				if (collides(objects[6], objects[i]))
				{
					cout << i << ": you collided" << endl;
				}
			}
			glm::vec3 dv;
			glm::vec3 dl;
			dv = objects[i].rigidBody.force / objects[i].rigidBody.mass * dt;
			objects[i].rigidBody.velocity += dv;
			objects[i].rigidBody.velocity.
			dl = objects[i].rigidBody.velocity * dt;
			objects[i].transform.loc += dl;
			//objects[6].rigidBody.force.x = -direction * 19;
			//objects[6].rigidBody.velocity -= .8f * objects[6].rigidBody.velocity * dt;//"drag"
			if (objects[6].transform.loc.y > minHeight)
			{
				objects[6].rigidBody.force.y -= 1;
			}
		}
		glfwSwapBuffers(GLFWwindowPtr);
		if (objects[6].transform.loc.y < minHeight)
		{
			objects[6].transform.loc.y = minHeight;
		}
		if (InputManager::getKey(GLFW_KEY_ESCAPE))
		{
			glfwSetWindowShouldClose(GLFWwindowPtr, GL_TRUE);
		}
		if (glfwGetKey(GLFWwindowPtr, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		{
			glfwTerminate();
			return 0;
		}
	}
	glfwTerminate();
	return true;
}
bool Engine::useShaders()
{
	bool loaded = shade.loadShaders("shaders/vShader.glsl", "shaders/fShader.glsl");
	if (loaded)
	{
		glUseProgram(shade.getProgram());
	}
	return loaded;
}