#include "Engine.h"

Engine::Engine()
{
}


Engine::~Engine()
{
}

bool Engine::init()
{
	if (glfwInit() == GL_FALSE)
	{
		return false;
	}
	GLFWwindowPtr = glfwCreateWindow(800, 600, " Gavin DSA1 Engine", NULL, NULL);

	if (GLFWwindowPtr != nullptr)
	{
		glfwMakeContextCurrent(GLFWwindowPtr);
	}
	else {
		glfwTerminate();
		return false;
	}
	if (glewInit() != GLEW_OK)
	{
		glfwTerminate();
		return false;
	}
	glClearColor(0.392f, 0.584f, 0.929f, 1.0f);
	return true;
}

bool Engine::bufferModel()
{
	std::vector<glm::vec3> locs = { { .9,.9,0 },{ -.9,.9,0 },{ 0,0,0 } ,{ -.9,-.9,0 },{ .9,-.9,0 } };

	std::vector<unsigned int> locInds = { 0,1,2,2,3,4 };

	vertCount = locInds.size();

	std::vector<glm::vec3> vertBufData(vertCount);

	for (unsigned int i = 0; i < vertCount; i++)
	{
		vertBufData[i] = locs[locInds[i]];
	}

	GLuint vertBuf;

	glGenVertexArrays(1, &vertArr);

	glGenBuffers(1, &vertBuf);

	glBindVertexArray(vertArr);

	glBindBuffer(GL_ARRAY_BUFFER, vertBuf);

	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vertCount, &vertBufData[0], GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(glm::vec3), 0);



	std::vector<glm::vec3> colors = { { .583f, 0.771f, .014f },{ .609f,.115f,.436f },{ .327f, .483f, .844f } ,{ .822f, .569f, .201f },{ .435f, .602f, .223f } };
	GLuint colorbuffer;
	glGenBuffers(1, &colorbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3), &colors, GL_STATIC_DRAW);

	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
	glVertexAttribPointer(1,3, GL_FLOAT,GL_FALSE,sizeof(glm::vec3),0);
	return true;
}

bool Engine::gameLoop()
{
	while (!glfwWindowShouldClose(GLFWwindowPtr))
	{




		glClear(GL_COLOR_BUFFER_BIT);

		glBindVertexArray(vertArr);

		glDrawArrays(GL_TRIANGLES, 0, vertCount);

		glfwSwapBuffers(GLFWwindowPtr);






		if (glfwGetKey(GLFWwindowPtr, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		{
			glfwTerminate();
			return 0;
		}

		glfwPollEvents();

	}

	glfwTerminate();
	return true;
}

bool Engine::useShaders()
{
	bool loaded = shade.loadShaders("vShader.glsl", "fShader.glsl");
	if (loaded)
	{
		glUseProgram(shade.getProgram());
	}
	return loaded;
}

