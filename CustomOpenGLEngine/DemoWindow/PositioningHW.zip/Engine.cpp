#include "Engine.h"

Engine::Engine()
{
}


Engine::~Engine()
{
	glDeleteTextures(2, texture);
	delete texture;
}

bool Engine::init()
{
	if (glfwInit() == GL_FALSE)
	{
		return false;
	}
	GLFWwindowPtr = glfwCreateWindow(800, 600, " Gavin DSA1 Engine", NULL, NULL);

	if (GLFWwindowPtr != nullptr)
	{
		glfwMakeContextCurrent(GLFWwindowPtr);
	}
	else {
		glfwTerminate();
		return false;
	}
	if (glewInit() != GLEW_OK)
	{
		glfwTerminate();
		return false;
	}

	InputManager::init(GLFWwindowPtr);
	for (int i = 0; i < 7; i++)
	{
		objects.push_back(Object());
		objects[i].filename = "textures/texture1.png";
		objects[i].transform.loc = glm::vec3(0, 0, 0);
		objects[i].transform.rot = glm::vec3(0, 0, 0);
		objects[i].transform.size = glm::vec3(1, 1, 1);
	}
	//object 0
	//default
	//object 1
	objects[1].filename = "textures/texture3.png";//white
	objects[1].transform.loc = glm::vec3(0, 0, 0);
	objects[1].transform.size = glm::vec3(1, .4, 1);
	//object 2
	objects[2].filename = "textures/texture4.png";//spike
	objects[2].transform.loc = glm::vec3(-.1, -.3, 0);
	objects[2].transform.size = glm::vec3(.08, .08, .08);
	//object 3
	objects[3].filename = "textures/texture4.png";//spike
	objects[3].transform.loc = glm::vec3(0, -.3, 0);
	objects[3].transform.size = glm::vec3(.08, .08, .08);
	//object 4
	objects[4].filename = "textures/texture4.png";//spike
	objects[4].transform.loc = glm::vec3(.1, -.3, 0);
	objects[4].transform.size = glm::vec3(.08, .08, .08);
	//object 5
	objects[5].filename = "textures/texture5.png";//peach
	objects[5].transform.loc = glm::vec3(.6, -.2, 0);
	objects[5].transform.size = glm::vec3(.2, .2, .2);
	//object 6
	objects[6].filename = "textures/texture6.png";//mario
	objects[6].transform.loc = glm::vec3(-.5, -.2, 0);
	objects[6].transform.size = glm::vec3(.2, .2, .2);
	return true;
}

bool Engine::bufferModel()
{
	std::vector<glm::vec3> locs ={{ 1, 1, 0 },{ -1, 1, 0 },{ -1, -1, 0 },{ 1, -1, 0 }};
	std::vector<unsigned int> locInds = { 0,1,2,0,2,3};
	vertCount = locInds.size();

	std::vector<glm::vec3> vertBufData(vertCount);
	for (unsigned int i = 0; i < vertCount; i++)
	{
		vertBufData[i] = locs[locInds[i]];
	}

	glGenVertexArrays(1, &vertArr);
	glGenBuffers(1, &vertBuf);

	glBindVertexArray(vertArr);
	glBindBuffer(GL_ARRAY_BUFFER, vertBuf);

	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vertCount, &vertBufData[0], GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(glm::vec3), 0);
	glClearColor(0.392f, 0.584f, 0.929f, 1.0f);
	return true;
}

bool Engine::useTextures(Object& o)
{
	texture = new GLuint[1];

	std::vector<Vertex> uvCoord
	{
		Vertex{glm::vec3(1, 1, 0),glm::vec2(1, 1)},
		Vertex{glm::vec3(-1, 1, 0),glm::vec2(0, 1)},
		Vertex{glm::vec3(-1, -1, 0),glm::vec2(0, 0)},
		Vertex{glm::vec3(1, -1, 0),	glm::vec2(1, 0)}
	};

	vector<unsigned int> locInds = { 0,1,2,0,2,3 };
	uvVertCount = locInds.size();
	vector<unsigned int> uvInds = { 0,1,2,0,2,3 };

	vector<Vertex> vertBufData(uvVertCount);
	for (unsigned int i = 0; i < uvVertCount; i++)
	{
		vertBufData[i] = uvCoord[uvInds[i]];
	}

	glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex) * uvVertCount, &vertBufData[0], GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)sizeof(glm::vec3));
	
	//texture loading
	FIBITMAP* texture1;
	//FIBITMAP* texture2;
	texture1 = FreeImage_Load(FIF_PNG, o.filename);
	try
	{
		//"textures/texture1.png", 0), "textures/texture1.png");
		//texture2 = FreeImage_Load(FreeImage_GetFileType(objects[i].filename, 0), objects[i].filename);//"textures/texture2.png", 0), "textures/texture2.png");
		//texture3 = FreeImage_Load(FreeImage)
	}
	catch (...)
	{
		if (texture1 == nullptr) return false;
		//if (texture2 == nullptr) return false;
	}

	FIBITMAP* image32Bit1 = FreeImage_ConvertTo32Bits(texture1);
	//FIBITMAP* image32Bit2 = FreeImage_ConvertTo32Bits(texture2);

	FreeImage_Unload(texture1);
	//FreeImage_Unload(texture2);

	glActiveTexture(GL_TEXTURE0);
	glGenTextures(1, &texture[0]);
	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_SRGB_ALPHA, FreeImage_GetWidth(image32Bit1), FreeImage_GetHeight(image32Bit1),
		0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(image32Bit1));

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	FreeImage_Unload(image32Bit1);
	//texture2
	/*glActiveTexture(GL_TEXTURE1);
	glGenTextures(1, &texture[1]);
	glBindTexture(GL_TEXTURE_2D, texture[1]);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_SRGB_ALPHA, FreeImage_GetWidth(image32Bit2), FreeImage_GetHeight(image32Bit2),
		0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(image32Bit2));

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	FreeImage_Unload(image32Bit2);
	glBindTexture(GL_TEXTURE_2D, 0);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture[index]);*/

	return true;
}
bool Engine::gameLoop()
{	
	index = 0;
	//useTextures();
	while (!glfwWindowShouldClose(GLFWwindowPtr))
	{
		glfwPollEvents();
		
		glClear(GL_COLOR_BUFFER_BIT);

		glBindVertexArray(vertArr);
	/*	
		objects[0].transform.matrix =
			glm::translate(
				objects[0].transform.loc)
			*
			glm::yawPitchRoll(
				objects[0].transform.rot.y,
				objects[0].transform.rot.x,
				objects[0].transform.rot.z)
			*
			glm::scale(
				objects[0].transform.size)
			;
		glUniformMatrix4fv(2, 1, GL_FALSE, &objects[0].transform.matrix[0][0]);
*/

		for (int i = 0; i < 7; i++)
		{
			objects[i].transform.matrix =
				glm::translate(
					objects[i].transform.loc)
				*
				glm::yawPitchRoll(
					objects[i].transform.rot.y,
					objects[i].transform.rot.x,
					objects[i].transform.rot.z)
				*
				glm::scale(
					objects[i].transform.size)
				;
			glUniformMatrix4fv(2, 1, GL_FALSE, &objects[i].transform.matrix[0][0]);
			useTextures(objects[i]);
			glDrawArrays(GL_TRIANGLES, 0, vertCount);
		}
		

		glfwSwapBuffers(GLFWwindowPtr);


		if (InputManager::getKey(GLFW_KEY_ESCAPE))
		{
			glfwSetWindowShouldClose(GLFWwindowPtr, GL_TRUE);
		}
		if (InputManager::getKey(GLFW_MOUSE_BUTTON_LEFT))
		{
			cout << "Was at index: " << index << endl;
			if (index >=1)
			{
				index = 0;
			}
			else
			{
				index++;
			}
			glBindTexture(GL_TEXTURE_2D, texture[index]);

			InputManager::releaseKey(GLFW_MOUSE_BUTTON_LEFT);
			cout << "Is now at index: " << index << endl;
		}



		if (glfwGetKey(GLFWwindowPtr, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		{
			glfwTerminate();
			return 0;
		}


	}

	glfwTerminate();
	return true;
}

bool Engine::useShaders()
{
	bool loaded = shade.loadShaders("shaders/vShader.glsl", "shaders/fShader.glsl");
	if (loaded)
	{
		glUseProgram(shade.getProgram());
	}
	return loaded;
}

