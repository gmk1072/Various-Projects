#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtx/euler_angles.hpp>
#include <FreeImage.h>
#include <vector>
#include "ShaderManager.h"
#include "InputManager.h"

struct Vertex
{
	glm::vec3 loc;
	glm::vec2 uv;
};

struct Transform
{
	glm::vec3 loc, rot, size;
	glm::mat4 matrix;
};

struct Object
{
	char* filename;
	Transform transform;
	//texture id
};

class Engine
{
private :
	GLFWwindow* GLFWwindowPtr;
	GLuint vertArr;
	GLuint vertBuf;
	unsigned int vertCount;
	ShaderManager shade;
	GLuint* texture;
	unsigned int uvVertCount;
	int index = 0;
	vector<Object> objects;
public:
	Engine();
	~Engine();
	bool init();
	bool bufferModel();
	bool gameLoop();
	bool useShaders();
	bool useTextures(Object& o);
};

