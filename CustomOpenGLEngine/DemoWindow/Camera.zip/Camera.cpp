#include "Camera.h"



Camera::Camera()
{
	transform.loc = { 0,0,1.5 };
	transform.rot = { 0,0,0 };
	rotMat = (glm::mat3)glm::yawPitchRoll(transform.rot.y, transform.rot.x, transform.rot.z);

	eye = transform.loc;
	center = eye + rotMat * glm::vec3(0, 0, -1);
	up = rotMat * glm::vec3(0, 1, 0);

	lookAtMat = glm::lookAt(eye, center, up);

	zoom = 1.f;
	width = 800;
	height = 600;

	fovy = 3.14150f * .4f / zoom;
	aspectRatio = (float)width / (float)height;
	zNear = .01f;
	zFar = 1000.f;

	perspectiveMat = glm::perspective(fovy, aspectRatio, zNear, zFar);

	camRot = glm::vec3();

}


Camera::~Camera()
{
}

void Camera::update(float dt, GLFWwindow *window)
{
	glfwSetInputMode(window,GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
	rigidBody.force = glm::vec3();
	//// Turn with mouse
	//float sens = .005;
	//int w = 800, h = 600;
	//double x, y;
	//glfwGetCursorPos(window, &x, &y);
	//camRot.y -= sens * (x - w * .5f); // Yaw
	//camRot.x -= sens * (y - h * .5f); // Pitch
	//camRot.x = glm::clamp(camRot.x, (-.5f * 3.1415f), (.5f * 3.1415f));
	//glfwSetCursorPos(window, w * .5f, h * .5f);

	// Move with arrows
	glm::vec3 dv;
	glm::mat3 R = (glm::mat3)glm::yawPitchRoll(camRot.y, camRot.x, camRot.z);
	if (InputManager::getKey(GLFW_KEY_LEFT))
		dv = R * glm::vec3(-1, 0, 0);
	if (InputManager::getKey(GLFW_KEY_RIGHT))
		dv = R * glm::vec3(1, 0, 0);
	if (InputManager::getKey(GLFW_KEY_UP))
		dv = R * glm::vec3(0, 0, -1);
	if (InputManager::getKey(GLFW_KEY_DOWN))
		dv = R * glm::vec3(0, 0, 1);
	float speed = .1f;
	if (dv != glm::vec3())
		dv = glm::normalize(dv) * speed;


	rigidBody.velocity *= .8;

	transform.matrix = glm::translate(transform.loc)*glm::yawPitchRoll(transform.rot.y + camRot.y, transform.rot.x + camRot.x, transform.rot.z + camRot.z)*glm::scale(transform.size);

	glm::vec3 dl;
	//dv = rigidBody.force / rigidBody.mass * dt;
	rigidBody.velocity += dv;
	dl = rigidBody.velocity * dt;
	transform.loc += dl;


	rotMat = (glm::mat3)glm::yawPitchRoll(transform.rot.y, transform.rot.x, transform.rot.z);

	eye = transform.loc;
	center = eye + rotMat * glm::vec3(0, 0, -1);
	up = rotMat * glm::vec3(0, 1, 0);
	lookAtMat = glm::lookAt(eye, center, up);//update lookat
	perspectiveMat = glm::perspective(fovy, aspectRatio, zNear, zFar);//update perspective

	camMat = perspectiveMat * lookAtMat;


	


	glUniformMatrix4fv(3, 1, GL_FALSE, &camMat[0][0]);







	
}
