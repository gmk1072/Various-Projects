#include "Engine.h"

Engine::Engine()
{
}


Engine::~Engine()
{
	glDeleteTextures(2, texture);
}

struct Vertex
{
	glm::vec3 loc;
	glm::vec2 uv;
};

bool Engine::init()
{
	if (glfwInit() == GL_FALSE)
	{
		return false;
	}
	GLFWwindowPtr = glfwCreateWindow(800, 600, " Gavin DSA1 Engine", NULL, NULL);

	if (GLFWwindowPtr != nullptr)
	{
		glfwMakeContextCurrent(GLFWwindowPtr);
	}
	else {
		glfwTerminate();
		return false;
	}
	if (glewInit() != GLEW_OK)
	{
		glfwTerminate();
		return false;
	}

	InputManager::init(GLFWwindowPtr);
	return true;
}

bool Engine::bufferModel()
{
	std::vector<glm::vec3> locs ={{ 0.9, 0.9, 0 },{ -0.9, 0.9, 0 },{ -0.9, -0.9, 0 },{ 0.9, -0.9, 0 }};
	std::vector<unsigned int> locInds = { 0,1,2,0,2,3};
	vertCount = locInds.size();

	std::vector<glm::vec3> vertBufData(vertCount);
	for (unsigned int i = 0; i < vertCount; i++)
	{
		vertBufData[i] = locs[locInds[i]];
	}

	glGenVertexArrays(1, &vertArr);
	glGenBuffers(1, &vertBuf);

	glBindVertexArray(vertArr);
	glBindBuffer(GL_ARRAY_BUFFER, vertBuf);

	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vertCount, &vertBufData[0], GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(glm::vec3), 0);
	glClearColor(0.392f, 0.584f, 0.929f, 1.0f);
	return true;
	/*std::vector<glm::vec3> colors = { { .583f, 0.771f, .014f },{ .609f,.115f,.436f },{ .327f, .483f, .844f } ,{ .822f, .569f, .201f },{ .435f, .602f, .223f } };
	GLuint colorbuffer;
	glGenBuffers(1, &colorbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3), &colors, GL_STATIC_DRAW);

	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
	glVertexAttribPointer(1,3, GL_FLOAT,GL_FALSE,sizeof(glm::vec3),0);*/
}

bool Engine::useTextures()
{
	texture = new GLuint[2];

	std::vector<Vertex> uvCoord
	{
		Vertex{glm::vec3(0.9, 0.9, 0),glm::vec2(0.95, 0.95)},
		Vertex{glm::vec3(-0.9, 0.9, 0),glm::vec2(0.05, 0.95)},
		Vertex{glm::vec3(-0.9, -0.9, 0),glm::vec2(0.05, 0.05)},
		Vertex{glm::vec3(0.9, -0.9, 0),	glm::vec2(0.95, 0.05)}
	};

	vector<unsigned int> locInds = { 0,1,2,0,2,3 };
	uvVertCount = locInds.size();
	vector<unsigned int> uvInds = { 0,1,2,0,2,3 };

	vector<Vertex> vertBufData(uvVertCount);
	for (unsigned int i = 0; i < uvVertCount; i++)
	{
		vertBufData[i] = uvCoord[uvInds[i]];
	}

	glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex) * uvVertCount, &vertBufData[0], GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)sizeof(glm::vec3));
	
	//texture loading
	FIBITMAP* texture1;
	FIBITMAP* texture2;
	try
	{
		texture1 = FreeImage_Load(FreeImage_GetFileType("texture1.png", 0), "texture1.png");
		texture2 = FreeImage_Load(FreeImage_GetFileType("texture2.png", 0), "texture2.png");
	}
	catch (...)
	{
		if (texture1 == nullptr) return false;
		if (texture2 == nullptr) return false;
	}

	FIBITMAP* image32Bit1 = FreeImage_ConvertTo32Bits(texture1);
	FIBITMAP* image32Bit2 = FreeImage_ConvertTo32Bits(texture2);

	FreeImage_Unload(texture1);
	FreeImage_Unload(texture2);

	glActiveTexture(GL_TEXTURE0);
	glGenTextures(1, &texture[0]);
	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_SRGB_ALPHA, FreeImage_GetWidth(image32Bit1), FreeImage_GetHeight(image32Bit1),
		0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(image32Bit1));

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	FreeImage_Unload(image32Bit1);
	//texture2
	glActiveTexture(GL_TEXTURE1);
	glGenTextures(1, &texture[1]);
	glBindTexture(GL_TEXTURE_2D, texture[1]);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_SRGB_ALPHA, FreeImage_GetWidth(image32Bit2), FreeImage_GetHeight(image32Bit2),
		0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(image32Bit2));

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	FreeImage_Unload(image32Bit2);
	glBindTexture(GL_TEXTURE_2D, 0);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture[index]);

	return true;
}
bool Engine::gameLoop()
{	
	index = 0;
	useTextures();
	while (!glfwWindowShouldClose(GLFWwindowPtr))
	{
		glfwPollEvents();
		
		glClear(GL_COLOR_BUFFER_BIT);

		glBindVertexArray(vertArr);
		glDrawArrays(GL_TRIANGLES, 0, vertCount);

		glfwSwapBuffers(GLFWwindowPtr);


		if (InputManager::getKey(GLFW_KEY_ESCAPE))
		{
			glfwSetWindowShouldClose(GLFWwindowPtr, GL_TRUE);
		}
		if (InputManager::getKey(GLFW_MOUSE_BUTTON_LEFT))
		{
			cout << "Was at index: " << index << endl;
			if (index ==1)
			{
				index = 0;
			}
			else
			{
				index++;
			}
			glBindTexture(GL_TEXTURE_2D, texture[index]);

			InputManager::releaseKey(GLFW_MOUSE_BUTTON_LEFT);
			cout << "Is now at index: " << index << endl;
		}



		if (glfwGetKey(GLFWwindowPtr, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		{
			glfwTerminate();
			return 0;
		}


	}

	glfwTerminate();
	return true;
}

bool Engine::useShaders()
{
	bool loaded = shade.loadShaders("vShader.glsl", "fShader.glsl");
	if (loaded)
	{
		glUseProgram(shade.getProgram());
	}
	return loaded;
}

