#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <FreeImage.h>
#include <vector>
#include "ShaderManager.h"
#include "InputManager.h"


class Engine
{
private :
	GLFWwindow* GLFWwindowPtr;
	GLuint vertArr;
	GLuint vertBuf;
	unsigned int vertCount;
	ShaderManager shade;
	GLuint* texture;
	unsigned int uvVertCount;
	int index = 0;

public:
	Engine();
	~Engine();
	bool init();
	bool bufferModel();
	bool gameLoop();
	bool useShaders();
	bool useTextures();
};

